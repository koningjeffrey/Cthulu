import React from 'react';
import {Link} from 'react-browser-router';
import axios from 'axios';

class Login extends React.Component {
    
    constructor(props) {
            super(props);
                this.state = {  files: [], comments: [], currentFile: {}, currentUser:  {}, 
                                currentUserId: 0, currentFileId: 0, message: ""};
                            
                this.saveLocalStorage = this.saveLocalStorage.bind(this);
                this.loadLocalStorage = this.loadLocalStorage.bind(this);
                
                this.loginUser = this.loginUser.bind(this);
                
                this.lEmail = React.createRef();
                this.lPassword = React.createRef();
	}
        
        componentDidMount() {
            this.loadLocalStorage();
        }
        saveLocalStorage() {
            localStorage.setItem('email', this.lEmail.current.value);
            localStorage.setItem('password', this.lPassword.current.value);
        }
        loadLocalStorage() {
            this.lEmail.current.value = localStorage.getItem('email');
            this.lPassword.current.value = localStorage.getItem('password');
        }
        loginUser(e)   {
            e.preventDefault();
            const data = new FormData();
                data.append("email", this.lEmail.current.value);
                data.append("password", this.lPassword.current.value);
                
            axios.post(`/api/login`, data)
                    .then(result => {
                        const user = result.data;
                        this.setState({currentUser: user, currentUserId: user.userId});
                        this.saveLocalStorage();
            });
        }
    
    render() {
      return  (
            <div className="box">
              <img src="Hexalent_logo_white.png" alt="Logo"/>
              <form onSubmit={this.loginUser}>
                  <div className="inputBox">
                      <input type="text" name="email" ref={this.lEmail}/>
                      <label>Email</label>
                  </div>
                  <div className="inputBox">
                      <input type="password" name="password" ref={this.lPassword}/>
                      <label>Password</label>
                  </div>
                  <input type="submit" name="submit" value="Login User"/>
                  <div className="regfor">
                    <Link to='/Register'>Register account</Link>
                  </div>  
              </form>
            </div>
        );
    }
  }

export default Login