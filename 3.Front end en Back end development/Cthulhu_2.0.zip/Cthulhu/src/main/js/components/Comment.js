import React from 'react'


class Comment extends React.Component{
    render(){
        return <div className="comment" key={comment.commentId}>
            <p>UserName</p>
            <p>{comment.commentField}</p>
        </div>
    }
}

export default Comment