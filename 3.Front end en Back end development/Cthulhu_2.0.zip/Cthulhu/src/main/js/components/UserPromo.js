import React from 'react';

class UserPromo extends React.Component {
    render() {
        return <div className="UserBlock">
                   <p>UserName</p>
                   <input type="submit" name="Remove" value="Remove"/>
                </div>
                
    }
  }

export default UserPromo