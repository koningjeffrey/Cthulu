import axios from 'axios';
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

import Login from './components/Login';
import Register from './components/Register';

const React = require('react');
const ReactDOM = require('react-dom');

class App extends React.Component {

	constructor(props) {
            super(props);
                this.state = {  files: [], comments: [], currentFile: {}, currentUser:  {}, 
                                currentUserId: 0, currentFileId: 0, message: ""};
	}

	render() {
		return (
                
                    <div>  
                     <Router>
                      <Switch>
                        <div className="App">
                            <Route exact path="/" component={Login}/>
                            <Route exact path="/Register" component={Register}/>
                        </div>
                      </Switch>
                    </Router>
                    </div>
                    );
                }
}

ReactDOM.render(
	<App />,
	document.getElementById('react')
);