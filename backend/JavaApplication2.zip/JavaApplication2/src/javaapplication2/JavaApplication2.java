
package javaapplication2;
import java.util.Scanner;
import java.sql.*;
//import voor je connection driver//

public class JavaApplication2 {
    
    public static void main(String[] args) {
        
        Scanner Sc = new Scanner(System.in);
        
        System.out.println("please enter: doelpunt_id");
        int doelpunt_id = Sc.nextInt();
        System.out.println("Please enter: sp_id");
        int sp_id = Sc.nextInt();
        System.out.println("Please enter:team_id");
        int team_id = Sc.nextInt();
        System.out.println("Please enter:wedstrijd_id");
        int wedstrijd_id = Sc.nextInt();
        System.out.println("Please enter:tijd");
        int tijd = Sc.nextInt();
        /*input voor alle waarden die naar je database moeten + initialiseren scanner. 
        Gaat nu via de console, moet natuurlijk uiteindelijk via de front-end.
        Doe ik nu vóór je een verbinding gaat maken met de DB, lijkt mij de meest veilige manier*/
        
         try{                   Connection con=DriverManager.getConnection(  
                "jdbc:mysql://localhost:3306/novi_bootcamp","root","password");  
                /*hier is localhost:3306 waar je de database host (3306 is standaard voor mysql), 
                novi_bootcamp de database naam, root is username, rest is password.
                !Uiteindelijk checken of er geen overbodige of standaard users in staan!*/
                
                String query = "insert into doelpunt(doelpunt_id,sp_id,team_id,wedstrijd_id,tijd)" + " values(?,?,?,?,?)"; 
                //Je query die naar de DB gaat definieër je als een string
                
                PreparedStatement preparedStmt = con.prepareStatement(query);
                    preparedStmt.setInt (1, doelpunt_id);
                    preparedStmt.setInt (2, sp_id);
                    preparedStmt.setInt (3, team_id);
                    preparedStmt.setInt (4, wedstrijd_id);
                    preparedStmt.setInt (5, tijd);
                /*En vervolgens maak je van die string een prepared statement, die gelinkt is aan je connectie,
                waar je waardes aan je query toevoegt*/  
                
                preparedStmt.execute();
                //Tenslotte voer je je prepared statement uit zodra de waarden erin zijn gevoegd

                    con.close(); 
                    //zodra je alle waarden door hebt gegeven, sluit je zo de connectie met de database meteen af
                    
            }catch(Exception e){ System.out.println(e);}  
        }  
    }  
