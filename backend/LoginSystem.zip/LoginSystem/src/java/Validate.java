import java.sql.*;

public class Validate {
    
    public static boolean checkUser(String username, String password)   {
        
        boolean st = false;
        
        try {
            Connection con=DriverManager.getConnection(  
                "jdbc:mysql://localhost:3306/login_oefen","root","$rF..P)qwer&9X");
            
            String query = "Select username,password from producers where username=? and password=?";
            
            PreparedStatement ps = con.prepareStatement(query);
                    ps.setString (1, username);
                    ps.setString (2, password);
                    
            ResultSet rs = ps.executeQuery();
            st = rs.next();
            con.close();
            
        }   catch(Exception e)   {
            e.printStackTrace();
        }
        return st;
    }
}
