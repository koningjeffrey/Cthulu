package javaapplication1;
import java.sql.*;
//import voor je connection driver//

public class JavaApplication1 {
    
    public static void main(String[] args) {
        
         try{   
                Connection con=DriverManager.getConnection(  
                "jdbc:mysql://localhost:3306/novi_bootcamp","root","password");  
                /*hier is localhost:3306 waar je de database host (3306 is standaard voor mysql), 
                novi_bootcamp de database naam, root is username, rest is password.
                !Uiteindelijk checken of er geen overbodige of standaard users in staan!*/

                Statement stmt=con.createStatement();  
                
                ResultSet rs=stmt.executeQuery("select * from doelpunt"); 
                //voert een SQL Query uit, en geeft dit als een resultaat terug
                
                    while(rs.next()) {
                        //je maakt hier een loop die doorloopt zolang je via de Resultset een resultaat binnen krijgt
                        
                System.out.println(
                        rs.getInt("doelpunt_id")+" "+rs.getInt("sp_id")+" "+rs.getInt("team_id")+" "+rs.getInt("wedstrijd_id")+" "+rs.getInt("tijd") ); 
                        //je print alle waarden die je binnenkrijgt van je ResultSet (in dit geval allemaal integers)
                    }
                    con.close(); 
                    //zodra je alle waarden binnen hebt, kom je uit je loop en sluit je zo de connectie met de database meteen af
                    
            }catch(Exception e){ System.out.println(e);}  
        }  
    }  
