package user;

public class User {
    private String username;
    private String password;
    private String firstName;
    private String lastName;
    private String country;
    private String email;
    public boolean valid;
    
    public String getUsername() {
        return username;
    }
    public void setUserName (String newUsername)    {
        username = newUsername;
    }    
    public String getFirstName()    {
        return firstName;
    }
    public void setFirstName(String newFirstName)   {
        firstName = newFirstName;
    }
    public String getLastName()    {
        return lastName;
    }
    public void setLastName(String newLastName)   {
        lastName = newLastName;
    }
    public String getCountry()  {
        return country;
    }
    public void setCountry (String newCountry)  {
        country = newCountry;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String newPassword) {
        password = newPassword;
    }
    public String getEmail()    {
        return email;
    }
    public void setEmail (String newEmail)  {
        email = newEmail;
    }
    public boolean isValid()    {
        return valid;
    }
    public void setValid(boolean newValid)  {
        valid = newValid;
    }
}