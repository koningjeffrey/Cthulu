package requests;

import user.User;
import java.text.*;
import java.util.*;
import java.sql.*;

public class UserQuery    {
    private static Connection currentCon = null;
    private static ResultSet rs = null;
    
    public static User login(User user) {
        PreparedStatement ps = null;
        
        String username = user.getUsername();
        String password = user.getPassword();
        
        try {
            currentCon = DBConnection.getConnection();
            
            String query = 
                "SELECT * FROM users WHERE username=? AND password=?";
        
         ps = currentCon.prepareStatement(query);
            ps.setString    (1, username);
            ps.setString    (2, password);
            
            rs = ps.executeQuery();
            boolean result = rs.next();
            
            if(!result)   {
                System.out.println("You are not a registered user! Please sign up first");
                user.setValid(false);
            }
            else if(result)   {
                String firstName = rs.getString("FirstName");
                String lastName = rs.getString("LastName");
                
                System.out.println("Welcome "+firstName);
                user.setFirstName(firstName);
                user.setLastName(lastName);
                user.setValid(true);
            }
        }   catch(Exception e)  {
            System.out.println("Log in failed: An Exception has occurred! "+ e);
        }
        
        finally {
        if(rs != null)  {
        try {
            rs.close();
        } catch (Exception e)   {}
        rs = null;
    }
        if(ps != null)  {
        try {
            ps.close();
        } catch (Exception e)   {}
        ps = null;
    }
        if(currentCon != null)  {
        try {
            currentCon.close();
        } catch (Exception e)   {}
        currentCon = null;
    }
    }
        return user;
    }
    
    public static User register(User user) {
        PreparedStatement ps = null;
        
        String username = user.getUsername();
        String firstName = user.getFirstName();
        String lastName = user.getLastName();
        String password = user.getPassword();
        String country = user.getCountry();
        String email = user.getEmail();
        
        try {
            currentCon = DBConnection.getConnection();
            
            String query = 
                "INSERT INTO users(username, first_name, last_name, email, country, password) VALUES(?,?,?,?,?,?)";
        
         ps = currentCon.prepareStatement(query);
            ps.setString    (1, username);
            ps.setString    (2, firstName);
            ps.setString    (3, lastName);
            ps.setString    (4, email);
            ps.setString    (5, country);
            ps.setString    (6, password);
            
            rs = ps.executeQuery();
            boolean result = rs.next();
            
            if(!result)   {
                System.out.println("Something went wrong!");
                user.setValid(false);
            }
            else if(result)   {
                System.out.println("Succesfully registered!");
                user.setValid(true);
            }
        }   catch(Exception e)  {
            System.out.println("Register in failed: An Exception has occurred! "+ e);
        }
        
        finally {
        if(rs != null)  {
        try {
            rs.close();
        } catch (Exception e)   {}
        rs = null;
    }
        if(ps != null)  {
        try {
            ps.close();
        } catch (Exception e)   {}
        ps = null;
    }
        if(currentCon != null)  {
        try {
            currentCon.close();
        } catch (Exception e)   {}
        currentCon = null;
    }
    }
        return user;
    }
}