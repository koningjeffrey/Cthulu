package requests;

import java.sql.*;
import java.util.*;

public class DBConnection {
    
    static Connection con;
    private static String url = "jdbc:mysql://localhost:3306/login_oefen";
    private static String username = "root";
    private static String password = "$rF..P)qwer&9X";
    
    public static Connection getConnection()   {
      
      try {
      Class.forName("com.mysql.jdbc.Driver");
            
      con = DriverManager.getConnection(url,username,password);
      
      }   catch(Exception e)   {
            e.printStackTrace();
      }
      return con;
      
    }
}
