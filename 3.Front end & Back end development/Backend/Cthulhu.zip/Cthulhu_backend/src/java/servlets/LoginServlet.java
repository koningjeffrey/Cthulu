package servlets;

import user.User;
import requests.UserQuery;
import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;

public class LoginServlet extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        try {  
            User user = new User();
            user.setUserName(request.getParameter("username"));
            user.setPassword(request.getParameter("password"));
            
            user = UserQuery.login(user);
        
            if(user.isValid())  {
                HttpSession session = request.getSession(true);
                session.setAttribute("currentSessionUser",user);
                response.sendRedirect("hexalent.html");//logged-in pagina
            }   else    {
                response.sendRedirect("Index.html");//error pagina
            }
            
        } catch(IOException Exception)    {
            System.out.println(Exception);
        }
        }    
    }
