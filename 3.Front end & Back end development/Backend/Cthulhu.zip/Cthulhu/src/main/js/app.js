const React = require('react');
const ReactDOM = require('react-dom');

import axios from 'axios';

class App extends React.Component {

	constructor(props) {
            super(props);
                this.state = {  files: [], comments: [], currentFile: {}, currentUser:  {}, 
                                currentUserId: 0, currentFileId: 0, message: ""};
                
                this.getFiles = this.getFiles.bind(this);
                this.getComments = this.getComments.bind(this);
                
                this.addComment = this.addComment.bind(this);
                this.addUser = this.addUser.bind(this);
                this.addFile = this.addFile.bind(this);
                
                this.loginUser = this.loginUser.bind(this);
                this.changeFile = this.changeFile.bind(this);
                
                this.commentField = React.createRef();
                this.filename = React.createRef();
                this.firstName = React.createRef();
                this.lastName = React.createRef();
                this.email = React.createRef();
                this.password = React.createRef();
	}   
            
        getFiles()  {
            axios.get('/api/files/' + this.state.currentUserId )
                .then(response => {
                    const files = response.data;
                    this.setState({files: files});
            });
        }

        getComments()   {
            axios.get('/api/comments' + this.state.currentFileId)
                .then(response =>   {
                    const comments = response.data;
                    this.setState({comments: comments});
            });
        }

        addComment(e)   {
            e.preventDefault();
            const data = new FormData();
                data.append("commentField", this.commentField.current.value);
                data.append("fileId", this.state.currentFileId);

            axios.post(`/api/comment`, data)
                .then(result => {
                    const createdComment = result.data;
                    this.setState({message: "Comment placed!"});
                    this.getComments();
            });
        }
        
        addUser(e)  {
            e.preventDefault();
            const data = new FormData();
                data.append("email", this.email.current.value);
                data.append("firstName", this.firstName.current.value);
                data.append("lastName", this.lastName.current.value);
                data.append("password", this.password.current.value);
            
            axios.post(`/api/user`, data)
                .then(result => {
                    const createdUser = result.data;
                    this.setState({message: "User Created!"});
            });    
        }
        
        addFile(e)    {
            e.preventDefault();
            const data = new FormData();
                data.append('filename', this.filename.current.value);
                data.append('userId', this.state.currentUserId);
            
            axios.post(`/api/file`, data)
                .then(result => {
                    const createdFile = result.data;
                    this.setState({ message: "File Added!" });
                    this.getFiles();
            });
        }

        changeFile(e)  {
            axios.get(`/api/files/` + this.state.currentFileId)
                .then(result => {
                    const file = result.data;
                    this.setState({currentFile: file, currentFileId: file.fileId});
            });
        }
        
        loginUser(e)   {
            e.preventDefault();
            const data = new FormData();
                data.append("email", this.email.current.value);
                data.append("password", this.password.current.value);
                
            axios.post(`/api/login`, data)
                    .then(result => {
                        const user = result.data;
                        this.setState({currentUser: user, currentUserId: user.userId, message: "Logged in!"});
                        this.getFiles();
            });
        }
    

	render() {
		return (
                
                    <div className="grid">
            
                        <div className="griditem">
                            <p>{this.state.message}</p>
                            <p>1. Add User</p>
                            <form onSubmit={this.addUser}>
                                <p>firstName:</p><input className="h2" type="text" ref={this.firstName}/>
                                <p>lastName:</p><input className="h2" type="text" ref={this.lastName}/>
                                <p>email:</p><input className="h2" type="text" ref={this.email}/>
                                <p>password:</p><input className="h2" type="password" ref={this.password}/>
                                <button className="btn" type="submit" value="Add User">Add User</button>
                            </form>
                        </div>
                        
                        <div className="griditem">
                                <p>{this.state.message}</p>
                                <form onSubmit={this.addComment}>
                                    <p>2. Add Comment</p>
                                    <p>Comment:</p><input className="h2" type="text" ref={this.commentField} />
                                    <button className="btn" type="submit" value="Add Comment">Add Comment</button>
                                </form>
                        </div>
                        
                        <div className="griditem">
                            <p>{this.state.message}</p>
                            <form onSubmit={this.addFile}>
                                <p>3. Add File</p>
                                <p>File:</p><input className="h2" type="text" ref={this.filename}/>
                                <button className="btn" type="submit" value="Add File">Add File</button>
                            </form>
                        </div>
                        
                        <div className="griditem">
                            <p>{this.state.message}</p>
                            <p>Login User:</p>
                            <form onSubmit={this.loginUser}>
                                <p>email:</p><input className="h2" type="text" ref={this.email} />
                                <p>password:</p><input className="h2" type="password" ref={this.password} />
                                <button className="btn" type="submit" value="Login User">Login User</button>
                            </form>
                        </div>
                        
                    </div>
                   
                     );
             }
         }

ReactDOM.render(
	<App />,
	document.getElementById('react')
);