import axios from 'axios';
import Cookies from 'universal-cookie';

const React = require('react');
const ReactDOM = require('react-dom');

class App extends React.Component {

	constructor(props) {
            super(props);
                this.state = {  files: [], comments: [], currentFile: {}, currentUser:  {}, 
                                currentUserId: 0, currentFileId: 0, message: ""};
                
                this.getFiles = this.getFiles.bind(this);
                this.getComments = this.getComments.bind(this);
                
                this.saveLocalStorage = this.saveLocalStorage.bind(this);
                this.loadLocalStorage = this.loadLocalStorage.bind(this);
                this.clearLocalStorage = this.clearLocalStorage.bind(this);

                this.addComment = this.addComment.bind(this);
                this.addUser = this.addUser.bind(this);
                this.addFile = this.addFile.bind(this);
                this.logoutUser = this.logoutUser.bind(this);
                this.loginUser = this.loginUser.bind(this);
                this.changeFile = this.changeFile.bind(this);
                
                this.commentField = React.createRef();
                this.filename = React.createRef();
                this.firstName = React.createRef();
                this.lastName = React.createRef();
                this.email = React.createRef();
                this.password = React.createRef();
                this.fileId = React.createRef();
	}
        
        componentDidMount() {
            this.loadLocalStorage();
            this.loginUser();
        }
   
        saveLocalStorage() {
            localStorage.setItem('email', this.email.current.value);
            localStorage.setItem('password', this.password.current.value);
        }
        loadLocalStorage() {
            this.email.current.value = localStorage.getItem('email');
            this.password.current.value = localStorage.getItem('password');
        }
        clearLocalStorage() {
            localStorage.removeItem('email');
            localStorage.removeItem('password');
        }
    
        getFiles()  {
            axios.get('/api/files/' + this.state.currentUserId )
                .then(response => {
                    const files = response.data;
                    this.setState({files: files});
            });
        }

        getComments()   {
            axios.get('/api/comments/' + this.state.currentFileId)
                .then(response =>   {
                    const comments = response.data;
                    this.setState({comments: comments});
            });
        }

        addComment(e)   {
            e.preventDefault();
            const data = new FormData();
                data.append("commentField", this.commentField.current.value);
                data.append("fileId", this.state.currentFileId);

            axios.post(`/api/comment`, data)
                .then(result => {
                    const createdComment = result.data;
                    this.setState({message: "Comment placed!"});
                    this.getComments();
            });
        }
        
        addUser(e)  {
            e.preventDefault();
            const data = new FormData();
                data.append("email", this.email.current.value);
                data.append("firstName", this.firstName.current.value);
                data.append("lastName", this.lastName.current.value);
                data.append("password", this.password.current.value);
            
            axios.post(`/api/user`, data)
                .then(result => {
                    const createdUser = result.data;
                    this.setState({message: "User Created!"});
            });    
        }
        
        addFile(e)    {
            e.preventDefault();
            const data = new FormData();
                data.append('filename', this.filename.current.value);
                data.append('userId', this.state.currentUserId);
            
            axios.post(`/api/file`, data)
                .then(result => {
                    const createdFile = result.data;
                    this.setState({ message: "File Added!" });
                    this.getFiles();
            });
        }

        changeFile(e)  {
            e.preventDefault();
            axios.get('/api/file/' + this.fileId.current.value)
                .then(response =>   {
                    const file = response.data;
                    this.setState({currentFile: file, currentFileId: file.fileId});
                    this.getComments();
            });
        }
        
        loginUser()   {
            const data = new FormData();
                data.append("email", this.email.current.value);
                data.append("password", this.password.current.value);
                
            axios.post(`/api/login`, data)
                    .then(result => {
                        const user = result.data;
                        this.setState({currentUser: user, currentUserId: user.userId});
                        this.saveLocalStorage();
                        this.getFiles();
            });
        }
        
        logoutUser(e)    {
            e.preventDefault();
            this.setState({ files: [], comments: [], currentFile: {}, currentUser:  {}, 
                            currentUserId: 0, currentFileId: 0, message: "Logged out!"});
            this.clearLocalStorage();
        }

	render() {
		return (
                
                    <div className="grid">
            
                        <div className="griditem">
                            <p>{this.state.message}</p>
                            <p>1. Add User:</p>
                            <form onSubmit={this.addUser}>
                                <p>firstName:</p><input className="h2" type="text" ref={this.firstName}/>
                                <p>lastName:</p><input className="h2" type="text" ref={this.lastName}/>
                                <p>email:</p><input className="h2" type="text" ref={this.email}/>
                                <p>password:</p><input className="h2" type="password" ref={this.password}/>
                                <button className="btn" type="submit" value="Add User">Add User</button>
                            </form>
                        </div>
                        
                        <div className="griditem">
                            <p>{this.state.message}</p>
                            <p>2. Login User:</p>
                            <form onSubmit={this.loginUser}>
                                <p>email:</p><input className="h2" type="text" ref={this.email} />
                                <p>password:</p><input className="h2" type="password" ref={this.password} />
                                <button className="btn" type="submit" value="Login User">Login User</button>
                            </form>
                            <button className="btn" type="submit" value="Logout User" onClick={this.logoutUser}>Logout User</button>
                        </div>
                        
                         <div className="griditem">
                            <p>{this.state.message}</p>
                            <p>3. Current File:</p>
                            <p>{this.state.currentFile.filename}</p>
                            <br/>
                            <form onSubmit={this.changeFile}>
                                <p>Insert fileId:</p><input className="h2" type="text" ref={this.fileId} />
                                <button className="btn" type="submit" value="Submit">File Id</button>
                            </form>
                        </div>
                        
                        <div className="griditem">
                            <p>{this.state.message}</p>
                            <p>4. File list:</p>
                            
                            {this.state.files.map(file  =>
                                <p key={file.fileId}> {file.fileId} , {file.filename}</p>)}
                            <br/>
                            
                            <form onSubmit={this.addFile}>
                                <p>Add File</p>
                                <p>Filename:</p><input className="h2" type="text" ref={this.filename}/>
                                <button className="btn" type="submit" value="Add File">Add File</button>
                            </form>
                        </div>

                        <div className="griditem">
                            <p>5. Comment list:</p>

                            {this.state.comments.map(comment =>
                                <p key={comment.commentId}> {comment.commentId} , {comment.commentField} </p>)}
                            <br/>
                            
                            <form onSubmit={this.addComment}>
                                <p>Add Comment</p>
                                <p>Commentfield:</p><input className="h2" type="text" ref={this.commentField} />
                                <button className="btn" type="submit" value="Submit">Add Comment</button>
                            </form>
                        </div>
                    </div>
                    );
                }
}

ReactDOM.render(
	<App />,
	document.getElementById('react')
);