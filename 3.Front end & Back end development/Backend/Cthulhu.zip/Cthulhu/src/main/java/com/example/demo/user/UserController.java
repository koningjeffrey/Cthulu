package com.example.demo.user;

import java.util.Optional;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class UserController {

    private UserRepository userRepository;

    public UserController(UserRepository userRepository)    {
        this.userRepository = userRepository;
    }
    
    @PostMapping("/api/login")
    public User loginUser(  @RequestParam("email")      String email,
                            @RequestParam("password")   String password)   {
        
        Optional<User> u = userRepository.findByEmailAndPassword(email, password);

        return u.isPresent() ? u.get() : null;
    }
    
    @PostMapping("/api/user")
    public User createUser( @RequestParam("email")      String email,
                            @RequestParam("firstName")  String firstName,
                            @RequestParam("lastName")   String lastName,
                            @RequestParam("password")   String password)  {
        
        User u = new User(email, firstName, lastName, password);
        User createdUser = userRepository.save(u);
        return createdUser;
    }
}