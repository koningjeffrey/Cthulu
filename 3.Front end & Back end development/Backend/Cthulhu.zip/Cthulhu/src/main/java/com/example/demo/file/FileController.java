package com.example.demo.file;

import java.util.List;
import java.util.Optional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FileController {
    
    private FileRepository fileRepository;
    
    public FileController(FileRepository fileRepository)    {
        this.fileRepository = fileRepository;
    }
    
    @GetMapping("/api/files/{currentUserId}")
    public List<File> getFilesByUserId(@PathVariable("currentUserId") Integer userId) {
        List <File> files = fileRepository.findByUserId(userId);
        
        return files;
    }
    @GetMapping("/api/file/{currentFileId}")
    public File getFileByFileId(@PathVariable("currentFileId") Integer fileId)   {
        
        Optional<File> f = fileRepository.findByFileId(fileId);

        return f.isPresent() ? f.get() : null;
    }
    
    @PostMapping("/api/file")
    public File createFile(     @RequestParam("filename")   String filename, 
                                @RequestParam("userId")     Integer userId) {
        
        File f = new File(filename, userId);
        File createdFile = fileRepository.save(f);
        return createdFile;
    }
}
