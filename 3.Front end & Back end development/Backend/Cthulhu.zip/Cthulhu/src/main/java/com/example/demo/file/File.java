package com.example.demo.file;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

@Entity
@Table(name="file")
public class File {
    
    @Id @GeneratedValue(strategy = GenerationType.AUTO) 
    private Integer fileId;
    
    private String filename;
    private Integer userId;
    
    private File()  {}
    
    public File(String filename, Integer userId)  {
        this.filename = filename;
        this.userId = userId;
    } 
    public void setFilename(String filename)    {
        this.filename = filename;
    }
    public String getFilename() {
        return filename;
    }
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    public Integer getUserId()  {
        return userId;
    }
    public Integer getFileId()  {
        return fileId;
    }
}
