package com.example.demo.comment;

import java.util.Optional;
import org.springframework.data.repository.CrudRepository;

public interface CommentRepository extends CrudRepository<Comment, Integer>{
    
    public Optional<Comment> findByFileId(Integer FileId);
}
