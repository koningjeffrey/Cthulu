package com.example.demo.comment;

import java.util.Optional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CommentController {
    
    private CommentRepository commentRepository;
    
    public CommentController(CommentRepository commentRepository)   {
        this.commentRepository = commentRepository;
    }
        
    @GetMapping("/api/comments/{currentFileId}")  
    public Comment getCommentByFileId(@PathVariable("currentFileId") Integer fileId)  {
        Optional <Comment> c = commentRepository.findById(fileId);
        
        return c.isPresent() ? c.get() : null;
    }
    
    @PostMapping("/api/comment")
    public Comment createComment(   @RequestParam("commentField")   String commentField, 
                                    @RequestParam("fileId")         Integer fileId) {
        
        Comment c = new Comment(commentField, fileId);
        Comment createdComment = commentRepository.save(c);
        return createdComment;
    }
}
