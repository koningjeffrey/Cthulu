package com.example.demo.file;

import org.springframework.data.repository.CrudRepository;

public interface FileRepository extends CrudRepository<File, Integer>{
    
}
